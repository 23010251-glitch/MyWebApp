document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Ngăn form gửi đi theo cách truyền thống

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const messageEl = document.getElementById('message');

    // Gửi yêu cầu POST đến server
    fetch('/api/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`,
    })
    .then(response => response.json())
.then(data => {
        if (data.success) {
            // Đăng nhập thành công, chuyển hướng đến trang dashboard
            messageEl.textContent = 'Đăng nhập thành công! Đang chuyển hướng...';
            messageEl.style.color = 'green';
            window.location.href = 'dashboard.html';
        } else {
            // Hiển thị thông báo lỗi
            messageEl.textContent = data.message;
            messageEl.style.color = 'red';
        }
    })
    .catch(error => {
        console.error('Lỗi:', error);
        messageEl.textContent = 'Có lỗi xảy ra, vui lòng thử lại.';
        messageEl.style.color = 'red';
    });
});