// Import các thư viện cần thiết
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

// Sử dụng body-parser để đọc dữ liệu từ form
app.use(bodyParser.urlencoded({ extended: true }));

// Thiết lập thư mục tĩnh cho trang quản trị
app.use(express.static(path.join(__dirname, 'admin')));

// Thiết lập thư mục tĩnh cho website bán hàng
app.use(express.static(path.join(__dirname)));

// Tài khoản quản trị viên "cứng"
const adminAccount = {
    username: 'admin',
    password: 'password123'
};

// API xử lý đăng nhập
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    if (username === adminAccount.username && password === adminAccount.password) {
        res.status(200).send({ success: true, message: 'Đăng nhập thành công!' });
    } else {
        res.status(401).send({ success: false, message: 'Tên đăng nhập hoặc mật khẩu không đúng.' });
    }
});

// Chuyển hướng đến trang quản trị
app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin', 'login.html'));
});

// Chuyển hướng đến trang chủ
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Khởi động server
app.listen(PORT, () => {
    console.log(`Server đang chạy tại http://localhost:${PORT}`);
    console.log(`Truy cập trang quản trị tại http://localhost:${PORT}/admin`);
});